<nav id="menu" class="primary">
	<?php
		wp_nav_menu(array(
			'theme_location' => 'primary',
			'menu_id' => 'main-menu',
		));
	?>
</nav>