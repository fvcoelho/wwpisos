<div id="footer-widgets">
	<div id="footer-widgets-wrapper">
		<?php dynamic_sidebar('Footer') ?>
		<div class="clear"></div>
	</div>
</div>