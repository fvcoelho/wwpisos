<p>
	<?php _e('SiteOrigin themes include a unique page building tool.', 'origami') ?>
	<?php _e('You can use this tool to create home and sub pages, filled your own widgets.', 'origami') ?>
	<?php _e('The page layouts are responsive and completely customizable.', 'origami') ?>
</p>
<p>
	<?php printf( __( "Read the <a href='%s' target='_blank'>full documentation</a> on SiteOrigin's support site.", 'origami' ), 'http://support.siteorigin.com/page-builder/' ) ?>
</p>